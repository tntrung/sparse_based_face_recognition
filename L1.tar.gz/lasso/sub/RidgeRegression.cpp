//#define ARRAY_ACCESS_INLINING
#include "mex.h"

class CMatrix
{
public:
    int M;
    int N;
	mxArray* m_Matrix;
    int IsConst;
    CMatrix()
    {
        M=N=0;
		m_Matrix = 0;
        IsConst = 0;
    }
    
    CMatrix(int M, int N)
    {
        this->M = M;
        this->N = N;
		m_Matrix = mxCreateDoubleMatrix(M, N, mxREAL);
        IsConst = 0;
    }
    
    CMatrix(mxArray* matrix, int IsConst = 1)
    {
        //int elements = mxGetNumberOfElements(prhs[0]);    
		/* The input must be a noncomplex scalar double.*/
		M = mxGetM(matrix);
		N = mxGetN(matrix);
        this->IsConst = IsConst;
        this->m_Matrix = matrix;
    }
    
    double* At(int i, int j)
    {        
        return (double *)mxGetPr(m_Matrix) + i + j*M;
    }
    
    double* InvAt(int i, int j)
    {        
        return (double *)mxGetPr(m_Matrix) + j+i*N;
    }
    
    int Transpose(mxArray*& pMatrix)
    {
       if(IsConst) 
       {
           mexErrMsgTxt("Cannot inverse a const Matrix");
           return 0;
       }
       mxArray* tMatrix = mxCreateDoubleMatrix(N, M, mxREAL);//inverse
       double* p = (double *)mxGetPr(tMatrix);
       //mexPrintf("Inverse\n");
       for(int i=0; i< M; i++)
       {
            for(int j=0; j< N; j++)
            {
                *(p+j+i*N) = *At(i,j);
                //mexPrintf("%4.2f ", *At(i,j));
            }
       }
       //Free();
       pMatrix = tMatrix;
       return 1;
    }
    
    int Free()
    {
        if(IsConst)
            return 0;
        mxDestroyArray(m_Matrix);
        m_Matrix = 0;
        M=N=0;
        return 1;
    }
    
    void Trace()
    {
        for(int i =0; i<M; i++)
        {
            for(int j =0; j<N; j++)
            {
                mexPrintf("%4.2f ", *At(i,j));
            }
            mexPrintf("\n");
        }
        //*At(0,0) = 5;
    }
    
    void InvTrace()
    {
        for(int i =0; i<N; i++)
        {
            for(int j =0; j<M; j++)
            {
                int k = j*N + i;
                mexPrintf("%4.2f %d %d\t", *InvAt(k/N, k%N), k/N, k%N);
            }
            mexPrintf("\n");
        }
        //*At(0,0) = 5;
    }
    
    CMatrix* Multiply(CMatrix* pMatrix)
    {
        if(this->N != pMatrix->M)
            return 0;
        CMatrix* pResult = new CMatrix(this->M, pMatrix->N);
        for(int row = 0; row<this->M; row++)
        {
            for(int col = 0; col<pMatrix->N; col++)
            {
                double val = 0;
                for(int k = 0; k<this->N; k++)
                {
                    val += *At(row,k) * (*pMatrix->At(k, col));
                }
                *pResult->At(row, col) = val;
            }
        }
            
        return pResult;
    }
    
    ~CMatrix()
    {
        M=N=0;
		m_Matrix = 0;
    }      
};

int parseX(mxArray *)
{
	return 1;
}

void mexFunction(int nlhs, mxArray *plhs[], int nrhs,
        const mxArray *prhs[]) 
{    
    int mrows, ncols;
    /* Check for proper number of arguments. */
    if (nrhs != 1) {
        mexErrMsgTxt("One input required.");
    } else if (nlhs > 1) {
        mexErrMsgTxt("Too many output arguments");
    }
    
    /* Get the number of elements in the input argument. */
    int elements = mxGetNumberOfElements(prhs[0]);    
    /* The input must be a noncomplex scalar double.*/
    mrows = mxGetM(prhs[0]);
    ncols = mxGetN(prhs[0]);
    double* pr = (double *)mxGetPr(prhs[0]);    
    if (!mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) 
            //|| !(mrows == 1 && ncols == 1)
            ) {        
        mexPrintf("Elements: %d M: %d, N: %d\n", elements, mrows, ncols);
        mexErrMsgTxt("Input must be a noncomplex scalar double.");
    }
    
    CMatrix* pX = new CMatrix((mxArray *)prhs[0], 0);
    //pX->Trace();
    //pX->InvTrace();
    mxArray* pMatrix = 0;
    if(pX->Transpose(pMatrix))
    {        
        CMatrix * pInvX = new CMatrix(pMatrix);
        //pInvX->Trace();
        CMatrix* pInvX_X = pInvX->Multiply(pX);
        if(pInvX_X >0)
        {
            plhs[0] = pInvX_X->m_Matrix;
        }        
        mxDestroyArray(pMatrix);
        delete pInvX;
        delete pInvX_X;
        //plhs[0] = mxCreateDoubleMatrix(2, 2, mxREAL);
    }    
    
    delete pX;
    
    /* Create matrix for the return argument. */
    //plhs[0] = mxCreateDoubleMatrix(mrocws, ncols, mxREAL);
    
    /* Assign pointers to each input and output. */
    //x = mxGetPr(prhs[0]);
    //y = mxGetPr(plhs[0]);
    
    /* Call the timestwo subroutine. */
    //timestwo(y, x);
}